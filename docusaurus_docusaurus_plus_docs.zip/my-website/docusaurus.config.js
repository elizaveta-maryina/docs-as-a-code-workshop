// @ts-check
// Note: type annotations allow type checking and IDEs autocompletion

const lightCodeTheme = require('prism-react-renderer/themes/github');
const darkCodeTheme = require('prism-react-renderer/themes/dracula');

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Документация курсового проекта',
  tagline: 'Единый центр управления заказами',
  favicon: 'img/favicon.ico',

  // --- GitHub Pages settings (замени плейсхолдеры) ---
  url: 'https://<username>.github.io',
  baseUrl: '/<repository-name>/',
  organizationName: '<username>',
  projectName: '<repository-name>',

  onBrokenLinks: 'warn',
  onBrokenMarkdownLinks: 'warn',
  trailingSlash: false,

  i18n: {
    defaultLocale: 'ru',
    locales: ['ru'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: require.resolve('./sidebars.js'),
          routeBasePath: '/',
          // PlantUML in Markdown: ```plantuml ...```
          remarkPlugins: [require('@akebifiky/remark-simple-plantuml')],
        },
        blog: false,
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      }),
    ],
  ],

  plugins: [
    // Draw.io diagrams in Markdown
    require.resolve('docusaurus-plugin-drawio'),
  ],

  themes: [
    // OpenAPI rendering (Redoc)
    [
      require.resolve('redocusaurus'),
      {
        specs: [
          {
            spec: 'openapi/openapi.yaml',
            route: '/api/',
          },
        ],
        theme: {
          primaryColor: '#2e8555',
        },
      },
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      navbar: {
        title: 'Курсовой проект',
        items: [
          { type: 'docSidebar', sidebarId: 'tutorialSidebar', position: 'left', label: 'Docs' },
          { to: '/api/', label: 'API', position: 'left' },
          {
            href: 'https://github.com/<username>/<repository-name>',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Документация',
            items: [
              { label: 'Обзор', to: '/' },
              { label: 'API', to: '/api/' },
            ],
          },
        ],
        copyright: `© ${new Date().getFullYear()}`,
      },
      prism: {
        theme: lightCodeTheme,
        darkTheme: darkCodeTheme,
      },
    }),
};

module.exports = config;
